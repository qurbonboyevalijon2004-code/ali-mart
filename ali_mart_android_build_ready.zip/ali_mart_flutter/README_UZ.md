# ALI MART — Android ilova namunasi

Bu Flutter asosidagi boshlang‘ich marketplace ilovasi. Funksiyalar:
- Bosh sahifa, qidiruv va kategoriya filtri
- Mahsulot kartalari va tafsilotlari
- Savatcha, miqdorni o‘zgartirish va jami narx
- Namunaviy sotuvchilar sahifasi
- Buyurtma tugmasi (demo ogohlantirish)

Mahsulotlar, narxlar, sotuvchilar va reytinglar namuna uchun. Ilova hozircha serverga buyurtma yubormaydi, to‘lov olmaydi yoki sotuvchi hisoblarini saqlamaydi.

## APK yaratish
Flutter SDK va Android SDK kerak.
1. Terminalda loyiha papkasiga kiring.
2. `flutter create . --platforms=android` (Android loyiha fayllari yo‘q bo‘lsa).
3. `flutter pub get`
4. `flutter run` bilan sinang.
5. `flutter build apk --release`
6. APK: `build/app/outputs/flutter-apk/app-release.apk`

Bu manba kodi; APK fayli Flutter/Android build muhiti orqali kompilyatsiya qilinishi kerak.

## Keyingi bosqich
Backend/database, login, sotuvchi kabineti, real buyurtmalar, to‘lov va yetkazib berish integratsiyasi.

## Kompyuterda Flutter o‘rnatmasdan APK olish (GitHub Actions)

Loyiha ichida `.github/workflows/build-apk.yml` mavjud. Loyihani GitHub’dagi yangi repository’ga yuklang. So‘ng repository ichidan **Actions → Build Ali Mart APK → Run workflow** ni tanlang. Jarayon muvaffaqiyatli tugagach, bajarilgan workflow sahifasining **Artifacts** qismidan `ali-mart-android-apk` faylini yuklab oling va ZIP ichidagi `app-release.apk` ni Android telefoningizga o‘rnating.

Eslatma: bu avtomatik build yo‘li APK’ni bulutdagi GitHub serverida kompilyatsiya qiladi; ilova hozircha demo ma’lumotlar bilan ishlaydi, haqiqiy server, login, to‘lov va buyurtma tizimi kiritilmagan.
