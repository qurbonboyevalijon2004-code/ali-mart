import 'package:flutter/material.dart';

void main() => runApp(const AliMartApp());

const purple = Color(0xFF6D28D9);
const orange = Color(0xFFFF8A00);

class Product {
  final String id, name, seller, category, emoji, description;
  final int price, oldPrice;
  final double rating;
  const Product(this.id, this.name, this.seller, this.category, this.emoji,
      this.price, this.oldPrice, this.rating, this.description);
}

const products = <Product>[
  Product('1','Simsiz quloqchin','Tech House','Elektronika','🎧',129000,179000,4.8,'Kundalik foydalanish uchun qulay simsiz quloqchin.'),
  Product('2','Sport krossovka','Fashion Uz','Kiyim','👟',249000,319000,4.7,'Yengil va qulay sport oyoq kiyimi.'),
  Product('3','Termos 500 ml','Uy Baraka','Uy-ro‘zg‘or','🥤',79000,99000,4.6,'Issiq va sovuq ichimliklar uchun ixcham termos.'),
  Product('4','Kundalik ryukzak','Fashion Uz','Kiyim','🎒',159000,199000,4.5,'O‘qish, ish va sayohat uchun ryukzak.'),
  Product('5','Smart soat','Tech House','Elektronika','⌚',299000,399000,4.8,'Vaqt va faollikni kuzatish uchun smart soat.'),
  Product('6','Stol chirog‘i','Uy Baraka','Uy-ro‘zg‘or','💡',99000,129000,4.4,'Ish stoli uchun chiroq.'),
  Product('7','Parvarish to‘plami','Go‘zallik Olami','Go‘zallik','🧴',89000,115000,4.6,'Shaxsiy parvarish uchun to‘plam.'),
  Product('8','Futbol to‘pi','Sport Market','Sport','⚽',119000,149000,4.7,'Mashg‘ulot va hordiq uchun futbol to‘pi.'),
];

String money(int n) {
  final s = n.toString();
  final b = StringBuffer();
  for (var i=0; i<s.length; i++) {
    if (i>0 && (s.length-i)%3==0) b.write(' ');
    b.write(s[i]);
  }
  return '$b so‘m';
}

class AliMartApp extends StatelessWidget {
  const AliMartApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title:'Ali Mart', debugShowCheckedModeBanner:false,
    theme:ThemeData(useMaterial3:true,colorScheme:ColorScheme.fromSeed(seedColor:purple),scaffoldBackgroundColor:const Color(0xFFF7F7FB)),
    home:const StoreHome(),
  );
}

class StoreHome extends StatefulWidget {
  const StoreHome({super.key});
  @override State<StoreHome> createState()=>_StoreHomeState();
}

class _StoreHomeState extends State<StoreHome> {
  int tab=0;
  String query='', category='Barchasi';
  final Map<String,int> cart={};
  int get count=>cart.values.fold(0,(a,b)=>a+b);
  int get total=>products.fold(0,(s,p)=>s+p.price*(cart[p.id]??0));
  void add(Product p) {
    setState(()=>cart[p.id]=(cart[p.id]??0)+1);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('${p.name} savatchaga qo‘shildi'),duration:const Duration(milliseconds:900),behavior:SnackBarBehavior.floating));
  }
  void qty(Product p,int d) { setState(() { final n=(cart[p.id]??0)+d; if(n<=0){cart.remove(p.id);}else{cart[p.id]=n;} }); }
  List<Product> get filtered=>products.where((p)=>(p.name.toLowerCase().contains(query.toLowerCase())||p.seller.toLowerCase().contains(query.toLowerCase()))&&(category=='Barchasi'||p.category==category)).toList();

  @override
  Widget build(BuildContext context) {
    final pages=[home(),catalog(),cartPage(),sellers()];
    return Scaffold(
      appBar:AppBar(title:Row(children:[
        Container(padding:const EdgeInsets.all(8),decoration:BoxDecoration(color:purple,borderRadius:BorderRadius.circular(11)),child:const Icon(Icons.shopping_bag,color:Colors.white)),
        const SizedBox(width:10),const Text('ALI MART',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:.5)),
      ]),actions:[IconButton(onPressed:()=>setState(()=>tab=2),icon:Badge(isLabelVisible:count>0,label:Text('$count'),child:const Icon(Icons.shopping_cart_outlined)))]),
      body:IndexedStack(index:tab,children:pages),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Bosh sahifa'),
        NavigationDestination(icon:Icon(Icons.grid_view_outlined),label:'Katalog'),
        NavigationDestination(icon:Icon(Icons.shopping_cart_outlined),label:'Savatcha'),
        NavigationDestination(icon:Icon(Icons.storefront_outlined),label:'Sotuvchilar'),
      ]),
    );
  }

  Widget search()=>Padding(padding:const EdgeInsets.fromLTRB(16,8,16,12),child:TextField(onChanged:(v)=>setState(()=>query=v),decoration:InputDecoration(hintText:'Mahsulotlarni qidiring',prefixIcon:const Icon(Icons.search),filled:true,fillColor:Colors.white,border:OutlineInputBorder(borderRadius:BorderRadius.circular(15),borderSide:BorderSide.none))));
  Widget title(String s)=>Padding(padding:const EdgeInsets.fromLTRB(16,10,16,12),child:Text(s,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w800)));
  Widget chips()=>SizedBox(height:48,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:12),children:['Barchasi','Elektronika','Kiyim','Uy-ro‘zg‘or','Go‘zallik','Sport'].map((c)=>Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:ChoiceChip(label:Text(c),selected:category==c,onSelected:(_)=>setState(()=>category=c))).toList()));
  Widget home()=>ListView(padding:const EdgeInsets.only(bottom:18),children:[
    search(),
    Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[purple,Color(0xFF9F67F5)]),borderRadius:BorderRadius.circular(22)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('ALI MART',style:TextStyle(color:Colors.white,fontSize:26,fontWeight:FontWeight.w900)),
      SizedBox(height:6),Text('Yoqtirgan mahsulotingiz bir necha bosishda!',style:TextStyle(color:Colors.white)),
      SizedBox(height:14),Row(children:[Icon(Icons.local_offer,color:Colors.white),SizedBox(width:8),Text('Ajoyib takliflar shu yerda',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w600))])
    ]))),
    title('Kategoriyalar'),chips(),title('Ommabop mahsulotlar'),grid(filtered)
  ]);
  Widget catalog()=>Column(children:[search(),chips(),Expanded(child:SingleChildScrollView(child:grid(filtered)))]);
  Widget grid(List<Product> list) {
    if(list.isEmpty)return const Padding(padding:EdgeInsets.all(30),child:Center(child:Text('Mahsulot topilmadi')));
    return GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),padding:const EdgeInsets.symmetric(horizontal:12),itemCount:list.length,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:.63,crossAxisSpacing:10,mainAxisSpacing:10),itemBuilder:(c,i)=>card(list[i]));
  }
  Widget card(Product p)=>Card(color:Colors.white,elevation:0,clipBehavior:Clip.antiAlias,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17),side:const BorderSide(color:Color(0xFFECECF2))),child:InkWell(onTap:()=>showModalBottomSheet(context:context,showDragHandle:true,builder:(_)=>details(p)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Expanded(child:Container(width:double.infinity,color:const Color(0xFFF0EBFF),child:Stack(children:[
      Center(child:Text(p.emoji,style:const TextStyle(fontSize:64))),
      Positioned(top:8,left:8,child:Container(padding:const EdgeInsets.all(5),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(7)),child:const Text('NAMUNA',style:TextStyle(fontSize:9,color:purple,fontWeight:FontWeight.bold)))),
      const Positioned(top:7,right:7,child:Icon(Icons.favorite_border,color:Colors.grey))
    ]))),
    Padding(padding:const EdgeInsets.all(9),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(p.name,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.bold)),
      Text(p.seller,style:const TextStyle(color:Colors.grey,fontSize:11)),
      Row(children:[const Icon(Icons.star,color:orange,size:14),Text(' ${p.rating}',style:const TextStyle(fontSize:12))]),
      Text(money(p.price),style:const TextStyle(fontWeight:FontWeight.w900,color:purple,fontSize:13)),
      Text(money(p.oldPrice),style:const TextStyle(decoration:TextDecoration.lineThrough,color:Colors.grey,fontSize:10)),
      SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>add(p),style:FilledButton.styleFrom(backgroundColor:purple,padding:const EdgeInsets.symmetric(vertical:6)),child:const Text('Savatchaga +',style:TextStyle(fontSize:12))))
    ]))
  ])));
  Widget details(Product p)=>SafeArea(child:Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
    Center(child:Container(height:140,width:140,decoration:BoxDecoration(color:const Color(0xFFF0EBFF),borderRadius:BorderRadius.circular(24)),child:Center(child:Text(p.emoji,style:const TextStyle(fontSize:78))))),
    const SizedBox(height:16),Text(p.name,style:const TextStyle(fontSize:23,fontWeight:FontWeight.w900)),Text('Sotuvchi: ${p.seller}'),const SizedBox(height:8),Text(money(p.price),style:const TextStyle(fontSize:21,color:purple,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text(p.description),const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton(onPressed:(){Navigator.pop(context);add(p);},child:const Text('Savatchaga qo‘shish')))
  ])));
  Widget cartPage() {
    final items=products.where((p)=>(cart[p.id]??0)>0).toList();
    if(items.isEmpty)return const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.shopping_cart_outlined,size:70,color:purple),SizedBox(height:12),Text('Savatchangiz hozircha bo‘sh',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),Text('Mahsulot tanlab, savatchaga qo‘shing')]));
    return Column(children:[
      Expanded(child:ListView.separated(padding:const EdgeInsets.all(14),itemCount:items.length,separatorBuilder:(_,__)=>const SizedBox(height:8),itemBuilder:(_,i){final p=items[i];final n=cart[p.id]??0;return Card(color:Colors.white,elevation:0,child:ListTile(leading:Text(p.emoji,style:const TextStyle(fontSize:32)),title:Text(p.name),subtitle:Text('${money(p.price)}\\n−     $n     +'),isThreeLine:true,trailing:Column(mainAxisAlignment:MainAxisAlignment.center,children:[IconButton(onPressed:()=>qty(p,-1),icon:const Icon(Icons.remove_circle_outline)),IconButton(onPressed:()=>qty(p,1),icon:const Icon(Icons.add_circle_outline))])));})),
      Container(color:Colors.white,padding:const EdgeInsets.all(18),child:Column(children:[
        Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Jami:',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),Text(money(total),style:const TextStyle(fontSize:19,color:purple,fontWeight:FontWeight.w900))]),
        const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Sinov buyurtmasi'),content:const Text('Bu namuna versiyasi. Haqiqiy buyurtma uchun server, mijoz ma’lumotlari va to‘lov/yetkazib berish tizimi kerak.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Yopish'))])),child:const Text('Buyurtma berish')))
      ]))
    ]);
  }
  Widget sellers() {
    final map=<String,List<Product>>{};for(final p in products){map.putIfAbsent(p.seller,()=>[]).add(p);}
    return ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Hamkor sotuvchilar',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),
      const SizedBox(height:6),const Text('Ali Mart namunaviy sotuvchilari va ularning mahsulotlari.'),
      const SizedBox(height:12),...map.entries.map((e)=>Card(color:Colors.white,elevation:0,child:ExpansionTile(leading:const CircleAvatar(backgroundColor:Color(0xFFF0EBFF),child:Icon(Icons.storefront,color:purple)),title:Text(e.key,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${e.value.length} ta mahsulot'),children:e.value.map((p)=>ListTile(leading:Text(p.emoji,style:const TextStyle(fontSize:26)),title:Text(p.name),subtitle:Text(money(p.price)),trailing:IconButton(icon:const Icon(Icons.add_shopping_cart),onPressed:()=>add(p)))).toList()))),
      const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('Eslatma: mahsulotlar va sotuvchilar namuna uchun. Haqiqiy sotuvchi kabineti keyingi bosqichda qo‘shiladi.')))
    ]);
  }
}
